# Finance Intelligence Agent (Finwise)

A minimal, classroom-friendly full-stack demo (React + Vite, Python FastAPI) of two AI patterns on personal-finance data:

- **Layer 1 – GenAI extraction:** paste raw transaction text or upload a receipt/statement; an LLM extracts structured JSON that is validated with Pydantic and shown on a dashboard.
- **Layer 2 – Agent audit:** a bounded (max 6 steps), ReAct-style loop calls an allowlist of deterministic Python tools to find silent subscription price hikes, annualise their cost, and draft a dispute message that is **held behind a human-approval gate**. Every step appears in a trace.

> **Educational demo, not financial advice.** It never sends email, contacts merchants or banks, or moves money. Approval is a local simulation.
>
> **Privacy warning:** use fictional or redacted data only. Do **not** upload real bank statements.

## Project structure

```
finance-intelligence-agent/
├── backend/
│   ├── app/
│   │   ├── ai_service.py   # AI boundary: STUB (hand-code Gemini here)
│   │   ├── main.py         # FastAPI routes, agent loop, in-memory sessions
│   │   ├── models.py       # Pydantic schemas
│   │   ├── sample_data.py  # Fictional transactions
│   │   └── tools.py        # Deterministic finance tools
│   ├── tests/test_tools.py
│   ├── .env.example
│   └── requirements.txt
├── frontend/               # React 18 + Vite 6 + Recharts
└── README.md
```

## Prerequisites

Python 3.11+ (3.12 recommended) and Node 20+.

## Run the backend

```bash
cd backend
python -m venv .venv
source .venv/bin/activate          # Windows (PowerShell): .venv\Scripts\Activate.ps1   (cmd: .venv\Scripts\activate.bat)
pip install -r requirements.txt
cp .env.example .env               # Windows: copy .env.example .env
uvicorn app.main:app --reload --port 8000
```

Interactive API docs: http://localhost:8000/docs

## Run the frontend

```bash
cd frontend
npm install
npm run dev                        # http://localhost:5173
npm run build                      # production build check
```

Optional: set `VITE_API_URL` (default `http://localhost:8000`), e.g. `VITE_API_URL=http://localhost:8001 npm run dev`.

## Run the tests

```bash
cd backend && pytest
```

## Configuration (`backend/.env`)

| Variable | Purpose |
|---|---|
| `GEMINI_API_KEY` | Gemini key. `replace_me` or empty = **demo mode** |
| `GEMINI_MODEL` | Default `gemini-2.5-flash` |
| `FRONTEND_ORIGIN` | CORS origin(s), comma-separated. Default `http://localhost:5173` |

The key lives only in `backend/.env` (git-ignored). The frontend never calls Gemini.

## 6-step demo flow

1. Open http://localhost:5173. Sample data loads automatically (14 transactions, $364.34 outflow, $221.34 subscriptions).
2. Review the monthly chart, category list and transactions table (raw source lines visible).
3. Click **Run agent audit** with the default goal.
4. Inspect the **+30% StreamBox Premium** card ($37.69 → $49.00, $588.00/year) and the agent trace.
5. Read the draft marked **NOT SENT**, then click **Approve simulation** (or **Reject**).
6. Try **Extract transactions** with the "Use example" text. In demo mode a red banner explains Gemini is not configured and your data stays intact.

## API

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/health` | Status + `gemini_configured` |
| GET | `/api/sample` | Fictional starter transactions |
| POST | `/api/extract` | Multipart `text` and/or `file` → validated transactions |
| POST | `/api/audits` | Start a bounded audit |
| GET | `/api/audits/{session_id}` | Read audit state and trace |
| POST | `/api/audits/{session_id}/approval` | `{"decision": "approve"\|"reject", "reason"?: str}` |

## Finishing the AI integration (developer task)

Only `backend/app/ai_service.py` needs editing. Search for `TODO(manual)`:

1. `_client()` – create `google.genai.Client(api_key=key)`.
2. `extract_statement()` – call Gemini with structured output (`response_schema=Statement`, `temperature=0`) using `SYSTEM_EXTRACTION_PROMPT`.
3. `choose_next_step()` – optional LLM planner returning `AgentDecision`. Until implemented, the deterministic offline planner is used.

`main.py` treats everything these functions return as **untrusted**: rows are re-validated, tool names are checked against the allowlist, and tool arguments are re-grounded against detected findings. Note: with a real key set but the stub unchanged, `/api/health` reports "Gemini connected" while `/api/extract` still returns an error until step 2 is implemented.

## Teaching notes and limitations

- Totals and money values are computed in Python/JavaScript, never by the LLM.
- Transaction text is treated as data (prompt-injection defence); the agent is capped at 6 steps and 4 allowlisted tools.
- State is in memory (`SESSIONS`), cleared on restart. No database, no auth, no file storage.
- Duplicate transactions are not de-duplicated. USD only. Only the first detected hike gets a draft.
- Raw upload contents and API keys are never logged.

## Troubleshooting

- **Frontend cannot connect / "Could not load sample data":** make sure the backend runs on port 8000; check `FRONTEND_ORIGIN` matches the URL in your browser (`localhost` vs `127.0.0.1` differ for CORS).
- **"Gemini is not configured":** add `GEMINI_API_KEY` to `backend/.env` and finish the manual integration, or use the sample data.
- **"Gemini extraction failed":** model, quota or network error; check `GEMINI_MODEL` and retry manually (no automatic retries).
- **Port in use:** run uvicorn on another port (e.g. `--port 8001`) and start the frontend with `VITE_API_URL=http://localhost:8001`.
