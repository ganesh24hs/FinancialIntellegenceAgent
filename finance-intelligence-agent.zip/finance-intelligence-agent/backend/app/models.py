"""Pydantic v2 schemas. These are the single source of truth for every payload."""
import datetime as dt
import uuid
from typing import Any, Literal

from pydantic import BaseModel, Field

Category = Literal[
    "Dining", "Fuel", "Shopping", "Subscriptions",
    "Food delivery", "Income", "Bills", "Other",
]

DEFAULT_GOAL = "Audit my transactions for subscription traps and silent price hikes."

ToolName = Literal[
    "detect_stealth_hikes",
    "calculate_annual_leakage",
    "generate_cancellation_script",
    "finish",
]


class Transaction(BaseModel):
    merchant: str = Field(min_length=1, max_length=120)
    date: dt.date | None = None  # null when unclear; never guessed (dt.date avoids shadowing)
    category: Category = "Other"
    amount: float = Field(allow_inf_nan=False)  # positive = charge, negative = refund/credit
    raw_line: str | None = None


class Statement(BaseModel):
    """AI extraction output schema."""
    transactions: list[Transaction]
    notes: list[str] = Field(default_factory=list)


class AuditRequest(BaseModel):
    transactions: list[Transaction]
    goal: str = DEFAULT_GOAL


class ApprovalRequest(BaseModel):
    decision: Literal["approve", "reject"]
    reason: str | None = None


class AgentDecision(BaseModel):
    tool_name: ToolName
    arguments: dict[str, Any] = Field(default_factory=dict)
    message: str = ""


class AuditSession(BaseModel):
    session_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    status: Literal["analyzing", "awaiting_approval", "executing", "done", "failed"] = "analyzing"
    goal: str
    findings: list[dict[str, Any]] = Field(default_factory=list)
    pending_action: dict[str, Any] | None = None
    audit_log: list[dict[str, Any]] = Field(default_factory=list)
    summary: str = ""
    steps: int = 0
