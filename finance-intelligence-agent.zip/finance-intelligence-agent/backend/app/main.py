"""FastAPI routes, bounded agent loop and in-memory sessions.

SAFETY (see README): nothing in this file sends email, contacts a merchant or bank,
or calls a payment API. The only outbound call in the whole project is the optional
Gemini call that lives in ai_service.py. Everything ai_service returns is UNTRUSTED.
"""
from __future__ import annotations

import asyncio
import csv
import io
import os
import threading
from collections import OrderedDict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, ValidationError

from .ai_service import choose_next_step, extract_statement
from .models import (
    DEFAULT_GOAL, AgentDecision, ApprovalRequest, AuditRequest, AuditSession, Transaction,
)
from .sample_data import sample_transactions
from .tools import calculate_annual_leakage, detect_stealth_hikes, generate_cancellation_script

load_dotenv(Path(__file__).resolve().parent.parent / ".env")

MAX_FILE_BYTES = 12 * 1024 * 1024  # 12 MB upload limit
MAX_TEXT_CHARS = 100_000           # cap on text sent to the AI
MAX_STEPS = 6                      # hard cap on agent iterations
MAX_SESSIONS = 200                 # keep the in-memory store bounded
ALLOWLIST = ["detect_stealth_hikes", "calculate_annual_leakage",
             "generate_cancellation_script", "finish"]

app = FastAPI(title="Finance Intelligence Agent (Finwise)", version="1.0.0")

# CORS: only the origins listed in FRONTEND_ORIGIN (comma-separated, trimmed).
_origins = [o.strip() for o in os.getenv("FRONTEND_ORIGIN", "http://localhost:5173").split(",") if o.strip()]
app.add_middleware(
    CORSMiddleware, allow_origins=_origins, allow_methods=["*"], allow_headers=["*"],
)

# In-memory only: cleared on restart. No database, no file storage of uploads.
SESSIONS: "OrderedDict[str, AuditSession]" = OrderedDict()
_approval_lock = threading.Lock()  # prevents a double-approval race


def _gemini_configured() -> bool:
    key = os.getenv("GEMINI_API_KEY")
    return bool(key) and key.strip() != "replace_me"


def _save(session: AuditSession) -> None:
    SESSIONS[session.session_id] = session
    SESSIONS.move_to_end(session.session_id)
    while len(SESSIONS) > MAX_SESSIONS:
        SESSIONS.popitem(last=False)


def _log(session: AuditSession, type_: str, message: str, details: Any = None) -> None:
    session.audit_log.append({
        "time": datetime.now(timezone.utc).isoformat(),
        "type": type_,
        "message": message,
        "details": details if details is not None else {},
    })


# ---------------------------------------------------------------- basic routes
@app.get("/api/health")
def health():
    return {"status": "ok", "gemini_configured": _gemini_configured()}


@app.get("/api/sample")
def sample():
    return {
        "transactions": [t.model_dump(mode="json") for t in sample_transactions()],
        "currency": "USD",
        "source": "fictional workshop sample",
    }


# ------------------------------------------------------------------ extraction
@app.post("/api/extract")
async def extract(text: str | None = Form(None), file: UploadFile | None = File(None)):
    text = (text or "").strip()
    if file is not None and not file.filename:  # browsers may send an empty file part
        file = None
    if not text and file is None:
        raise HTTPException(400, "Paste transaction text or choose a file.")

    file_bytes: bytes | None = None
    mime = "application/octet-stream"
    filename = ""
    if file is not None:
        file_bytes = await file.read(MAX_FILE_BYTES + 1)  # never buffer more than the limit
        if len(file_bytes) == 0:
            raise HTTPException(400, "The selected file is empty.")
        if len(file_bytes) > MAX_FILE_BYTES:
            raise HTTPException(413, "Please use a file smaller than 12 MB for this classroom demo.")
        mime = file.content_type or mime
        filename = (file.filename or "").lower()

    is_csv = mime == "text/csv" or filename.endswith(".csv")
    try:
        if is_csv:
            # Python parses the table; the AI only normalises (and never invents values).
            try:
                decoded = file_bytes.decode("utf-8-sig")
            except UnicodeDecodeError:
                raise HTTPException(400, "CSV must be UTF-8 encoded.")
            try:
                rows = list(csv.DictReader(io.StringIO(decoded)))
            except csv.Error as e:
                raise HTTPException(400, f"Could not read CSV: {e}")
            if not rows:
                raise HTTPException(400, "Could not read CSV: no data rows found.")
            prompt = ("CSV rows (extract/normalize only; do not invent values):\n" + repr(rows))
            statement = await asyncio.to_thread(extract_statement, text=prompt[:MAX_TEXT_CHARS])
        else:
            statement = await asyncio.to_thread(
                extract_statement,
                text=text[:MAX_TEXT_CHARS] or None,
                file_bytes=file_bytes,
                mime_type=mime if file_bytes is not None else None,
            )
    except HTTPException:
        raise
    except RuntimeError as e:  # "Gemini is not configured..." (E6)
        raise HTTPException(503, str(e))
    except Exception as e:  # network, quota, bad JSON, not implemented... (E7)
        raise HTTPException(502, f"Gemini extraction failed: {e}")

    # Second validation layer: the AI output is untrusted, re-validate every row.
    raw = statement.get("transactions", []) if isinstance(statement, dict) else getattr(statement, "transactions", [])
    notes_raw = statement.get("notes", []) if isinstance(statement, dict) else getattr(statement, "notes", [])
    valid: list[dict] = []
    errors: list[dict] = []
    for i, item in enumerate(raw or []):
        try:
            data = item.model_dump() if isinstance(item, BaseModel) else item
            valid.append(Transaction.model_validate(data).model_dump(mode="json"))
        except ValidationError as e:
            errors.append({"row": i + 1, "error": "; ".join(
                f"{'.'.join(map(str, err['loc']))}: {err['msg']}" for err in e.errors())})
        except Exception as e:
            errors.append({"row": i + 1, "error": str(e)})
    return {
        "transactions": valid,
        "notes": [str(n) for n in (notes_raw or [])],
        "validation_errors": errors,
        "count": len(valid),
    }


# ----------------------------------------------------------------- agent loop
def _summary(findings: list[dict]) -> str:
    """L9: summary text. All arithmetic is done here in Python."""
    if not findings:
        return "No subscription price hikes above 10% were found in the provided data."
    return " ".join(
        f"{f['merchant']} increased from ${f['old_amount']:.2f} to ${f['new_amount']:.2f} "
        f"(+{f['change_pct']:.1f}%). Current annualized cost: ${f['new_amount'] * 12:.2f}."
        for f in findings
    )


def _to_float(v: Any) -> float | None:
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _coerce_decision(raw: Any) -> AgentDecision:
    """Treat the planner output as untrusted: enforce the allowlist, then validate."""
    data = raw.model_dump() if isinstance(raw, BaseModel) else raw
    if not isinstance(data, dict):
        raise ValueError("Planner returned an invalid decision")
    name = data.get("tool_name")
    if name not in ALLOWLIST:
        raise ValueError(f"Tool is not allowed: {name}")
    return AgentDecision.model_validate(data)


def _match_finding(findings: list[dict], merchant: Any, amount: float | None = None) -> dict | None:
    """Ground planner arguments: never trust model-supplied merchants/amounts."""
    if amount is not None:
        for f in findings:
            if f["merchant"] == merchant and abs(f["new_amount"] - amount) < 0.001:
                return f
    else:
        for f in findings:
            if f["merchant"] == merchant:
                return f
    return findings[0] if findings else None


def run_audit(transactions: list[Transaction], goal: str) -> AuditSession:
    session = AuditSession(goal=goal)
    _log(session, "started", "Audit started.", {"transaction_count": len(transactions)})
    tool_results: list[dict] = []
    try:
        for _ in range(MAX_STEPS):
            session.steps += 1
            decision = _coerce_decision(
                choose_next_step(goal, session.findings, tool_results, list(ALLOWLIST))
            )
            tool, args = decision.tool_name, decision.arguments
            _log(session, "plan", decision.message or f"Selected {tool}.",
                 {"tool": tool, "arguments": args})

            if tool == "finish":
                break

            if tool == "detect_stealth_hikes":
                result: Any = detect_stealth_hikes(transactions)
                session.findings = result

            elif tool == "calculate_annual_leakage":
                f = _match_finding(session.findings, args.get("merchant"), _to_float(args.get("monthly_amount")))
                result = (calculate_annual_leakage(f["merchant"], f["new_amount"])
                          if f else {"skipped": "No price hike found."})

            elif tool == "generate_cancellation_script":
                f = _match_finding(session.findings, args.get("merchant"))
                if f:
                    result = generate_cancellation_script(f["merchant"], f["old_amount"], f["new_amount"])
                    session.pending_action = {
                        "type": "review_subscription_change",
                        "merchant": f["merchant"],
                        "old_amount": f["old_amount"],
                        "new_amount": f["new_amount"],
                        "change_pct": f["change_pct"],
                        "date": f["date"],
                        "annual_cost": round(f["new_amount"] * 12, 2),
                        "monthly_increase": f["monthly_increase"],
                        "draft": result["draft"],
                        "sent": False,
                    }
                else:
                    result = {"skipped": "No price hike found."}
            else:  # unreachable thanks to the allowlist, kept as defence in depth
                raise ValueError("Tool is not allowed")

            tool_results.append({"tool": tool, "result": result})
            _log(session, "tool", f"Executed {tool}.", result)

            if tool == "generate_cancellation_script" and session.pending_action:
                # Consequential step: STOP and wait for an explicit human decision.
                session.status = "awaiting_approval"
                session.summary = _summary(session.findings)
                _log(session, "approval_required",
                     "Draft ready. Waiting for human approval; nothing has been sent.")
                _save(session)
                return session

        session.status = "done"
        session.summary = _summary(session.findings) or \
            "Audit completed. No subscription price hikes above the threshold were found."
        _log(session, "completed", "Audit completed.", {"steps": session.steps})
    except Exception as e:  # any failure ends the audit safely
        session.status = "failed"
        session.summary = f"Audit stopped safely: {e}"
        session.pending_action = None
        _log(session, "error", str(e))
    _save(session)
    return session


@app.post("/api/audits")
def start_audit(req: AuditRequest):
    if not req.transactions:
        raise HTTPException(400, "Add transactions before starting an audit.")
    return run_audit(req.transactions, req.goal.strip() or DEFAULT_GOAL)


@app.get("/api/audits/{session_id}")
def get_audit(session_id: str):
    session = SESSIONS.get(session_id)
    if session is None:
        raise HTTPException(404, "Audit session not found.")
    return session


@app.post("/api/audits/{session_id}/approval")
def decide(session_id: str, req: ApprovalRequest):
    with _approval_lock:
        session = SESSIONS.get(session_id)
        if session is None:
            raise HTTPException(404, "Audit session not found. Start a new audit.")
        if session.status != "awaiting_approval" or not session.pending_action:
            raise HTTPException(409, "This audit has no pending approval.")

        action = session.pending_action
        if req.decision == "approve":
            session.status = "executing"
            # LOCAL SIMULATION ONLY. Nothing is sent anywhere; `sent` stays False.
            action["simulated_execution"] = "Approved and recorded locally; no external message was sent."
            action["approved"] = True
            _log(session, "approved_simulation",
                 "Human approved the action. Simulated locally; no message was sent.",
                 {"merchant": action["merchant"], "reason": req.reason})
            session.status = "done"
            session.summary += " Demo action approved and simulated; no message was sent."
        else:
            action["approved"] = False
            _log(session, "rejected", "Human rejected the proposed action. Nothing was sent.",
                 {"merchant": action["merchant"], "reason": req.reason})
            session.status = "done"
            session.summary += " Proposed action rejected; nothing was sent."
        action["sent"] = False
        _save(session)
        return session
