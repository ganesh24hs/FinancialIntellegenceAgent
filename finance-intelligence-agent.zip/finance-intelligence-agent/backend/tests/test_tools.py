"""Run with: cd backend && pytest"""
from datetime import date

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.models import Transaction
from app.sample_data import sample_transactions
from app.tools import calculate_annual_leakage, detect_stealth_hikes, generate_cancellation_script


def _sub(merchant, d, amount):
    return Transaction(merchant=merchant, date=date.fromisoformat(d), category="Subscriptions", amount=amount)


def test_sample_contains_expected_price_hike():
    hikes = detect_stealth_hikes(sample_transactions())
    assert len(hikes) == 1
    h = hikes[0]
    assert h["merchant"] == "StreamBox Premium"
    assert (h["old_amount"], h["new_amount"], h["change_pct"]) == (37.69, 49.0, 30.0)
    assert h["date"] == "2026-08-03" and h["monthly_increase"] == 11.31


def test_annual_cost():
    assert calculate_annual_leakage("StreamBox Premium", 49.0)["annual_cost"] == 588.0


def test_draft_is_not_sent():
    r = generate_cancellation_script("StreamBox Premium", 37.69, 49.0)
    assert r["sent"] is False
    assert "$11.31" in r["draft"] and "$37.69" in r["draft"] and "$49.00" in r["draft"]


def test_no_hike_for_flat_spotify():
    rows = [t for t in sample_transactions() if t.merchant == "Spotify"]
    assert detect_stealth_hikes(rows) == []


def test_exact_ten_percent_not_flagged():
    assert detect_stealth_hikes([_sub("X", "2026-01-01", 10.0), _sub("X", "2026-02-01", 11.0)]) == []


def test_negative_monthly_amount_raises():
    with pytest.raises(ValueError):
        calculate_annual_leakage("X", -1.0)


# ---------------------------------------------------------------- API (offline)
client = TestClient(app)


def _audit():
    body = {"transactions": [t.model_dump(mode="json") for t in sample_transactions()]}
    return client.post("/api/audits", json=body).json()


def test_health_and_sample():
    assert client.get("/api/health").json()["status"] == "ok"
    s = client.get("/api/sample").json()
    assert len(s["transactions"]) == 14 and s["currency"] == "USD"


def test_audit_awaits_approval_with_expected_trace():
    s = _audit()
    assert s["status"] == "awaiting_approval" and s["steps"] == 3
    assert len(s["findings"]) == 1
    assert s["pending_action"]["annual_cost"] == 588.0 and s["pending_action"]["sent"] is False
    types = [e["type"] for e in s["audit_log"]]
    assert types == ["started", "plan", "tool", "plan", "tool", "plan", "tool", "approval_required"]
    assert s["summary"] == "StreamBox Premium increased from $37.69 to $49.00 (+30.0%). Current annualized cost: $588.00."


def test_approve_then_second_approval_conflicts():
    s = _audit()
    url = f"/api/audits/{s['session_id']}/approval"
    r = client.post(url, json={"decision": "approve"})
    assert r.status_code == 200 and r.json()["status"] == "done"
    assert r.json()["pending_action"]["approved"] is True
    assert r.json()["summary"].endswith("Demo action approved and simulated; no message was sent.")
    assert client.post(url, json={"decision": "approve"}).status_code == 409
    assert client.post("/api/audits/nope/approval", json={"decision": "approve"}).status_code == 404


def test_reject():
    s = _audit()
    r = client.post(f"/api/audits/{s['session_id']}/approval", json={"decision": "reject"}).json()
    assert r["pending_action"]["approved"] is False and r["pending_action"]["sent"] is False
    assert r["summary"].endswith("Proposed action rejected; nothing was sent.")


def test_audit_validation_and_no_hike():
    assert client.post("/api/audits", json={"transactions": []}).status_code == 400
    spot = [t.model_dump(mode="json") for t in sample_transactions() if t.merchant == "Spotify"]
    s = client.post("/api/audits", json={"transactions": spot}).json()
    assert s["status"] == "done" and s["findings"] == []
    assert "No subscription price hikes above 10%" in s["summary"]


def test_extract_errors_offline():
    assert client.post("/api/extract", data={"text": ""}).status_code == 400
    r = client.post("/api/extract", data={"text": "2026-09-14 TST* SPOTIFY USA 11.99"})
    assert r.status_code == 503 and "Gemini is not configured" in r.json()["detail"]
    assert client.post("/api/extract", files={"file": ("a.txt", b"", "text/plain")}).status_code == 400
    big = b"x" * (13 * 1024 * 1024)
    assert client.post("/api/extract", files={"file": ("a.txt", big, "text/plain")}).status_code == 413
