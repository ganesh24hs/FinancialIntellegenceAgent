import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Activity, AlertCircle, ArrowDownLeft, ArrowUpRight, Bot, Check, FileText,
  LayoutDashboard, Loader2, Receipt, RefreshCw, Repeat, ShieldCheck, Sparkles,
  TrendingUp, UploadCloud, Wallet, X,
} from "lucide-react";
import {
  Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";

const API = (import.meta.env.VITE_API_URL || "http://localhost:8000").replace(/\/$/, "");
const MAX_FILE_BYTES = 12 * 1024 * 1024;
const DEFAULT_GOAL = "Audit my transactions for subscription traps and silent price hikes.";
const EXAMPLE_TEXT = [
  "2026-09-14 TST* SPOTIFY USA 11.99",
  "2026-09-18 UPI/FOOD DELIVERY/8231 18.75",
  "2026-09-20 POS HPCL FUEL HYD 25.00",
].join("\n");
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const CAT_COLORS = ["#6d78e8", "#8b5cf6", "#f59e0b", "#10b981", "#0ea5e9", "#ef4444"];
const AVATAR_COLORS = ["#6d78e8", "#8b5cf6", "#f59e0b", "#10b981", "#0ea5e9", "#ec4899"];

// ------------------------------------------------------------------ helpers
const usd = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" });
const money = (n) => usd.format(n);

// Parse "YYYY-MM-DD" without timezone shifts.
function parseDate(s) {
  if (!s) return null;
  const [y, m, d] = s.split("-").map(Number);
  return { y, m, d, key: y * 10000 + m * 100 + d };
}
const fmtDay = (s) => {
  const p = parseDate(s);
  return p ? `${MONTHS[p.m - 1]} ${p.d}` : "Date unclear";
};
const fmtTime = (iso) =>
  new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false });

async function request(path, options) {
  const res = await fetch(`${API}${path}`, options);
  let data = null;
  try { data = await res.json(); } catch { /* non-JSON body */ }
  if (!res.ok) {
    const d = data?.detail;
    const msg = Array.isArray(d) ? d.map((e) => e.msg).join("; ") : d;
    throw new Error(msg || `Request failed (${res.status}).`);
  }
  return data;
}

// All dashboard maths happens here in code (never by the LLM). Recomputed on change.
function computeDashboard(transactions) {
  const charges = transactions.filter((t) => t.amount > 0);
  const totalOutflow = charges.reduce((s, t) => s + t.amount, 0);
  const subscriptions = charges.filter((t) => t.category === "Subscriptions").reduce((s, t) => s + t.amount, 0);

  const byMonth = {};
  charges.forEach((t) => {
    const p = parseDate(t.date);
    if (!p) return;
    const key = `${p.y}-${String(p.m).padStart(2, "0")}`;
    byMonth[key] = (byMonth[key] || 0) + t.amount;
  });
  const monthly = Object.keys(byMonth).sort().map((key) => {
    const [y, m] = key.split("-").map(Number);
    return { label: `${MONTHS[m - 1]} ${String(y).slice(2)}`, amount: Math.round(byMonth[key] * 100) / 100 };
  });

  const byCat = {};
  charges.forEach((t) => { byCat[t.category] = (byCat[t.category] || 0) + t.amount; });
  const categories = Object.entries(byCat).sort((a, b) => b[1] - a[1]).slice(0, 6)
    .map(([name, amount]) => ({ name, amount }));

  const rows = [...transactions].sort((a, b) => {
    const pa = parseDate(a.date), pb = parseDate(b.date);
    if (!pa && !pb) return 0;
    if (!pa) return 1;
    if (!pb) return -1;
    return pb.key - pa.key;
  });

  return {
    count: transactions.length,
    merchants: new Set(transactions.map((t) => t.merchant)).size,
    totalOutflow, subscriptions, monthly, categories, rows,
  };
}

// ------------------------------------------------------------- small pieces
function Spinner() { return <Loader2 size={16} className="spin" aria-hidden="true" />; }

function Avatar({ name }) {
  const letter = (name || "?").trim().charAt(0).toUpperCase() || "?";
  const color = AVATAR_COLORS[letter.charCodeAt(0) % AVATAR_COLORS.length];
  return <span className="avatar-letter" style={{ background: `${color}22`, color }}>{letter}</span>;
}

function MetricCard({ icon: Icon, tone, label, value, sub }) {
  return (
    <div className="card metric">
      <span className={`metric-icon tone-${tone}`}><Icon size={20} /></span>
      <div>
        <div className="metric-label">{label}</div>
        <div className="metric-value">{value}</div>
        <div className="metric-sub">{sub}</div>
      </div>
    </div>
  );
}

function Sidebar({ count, onNav }) {
  return (
    <aside className="sidebar">
      <div className="brand">
        <span className="brand-icon"><Activity size={20} /></span>
        <div>
          <div className="brand-name">Finwise</div>
          <div className="brand-caption">INTELLIGENCE AGENT</div>
        </div>
      </div>
      <div className="nav-label">WORKSPACE</div>
      <nav className="nav">
        <button className="nav-item active" onClick={() => onNav("overview")}>
          <LayoutDashboard size={18} /> Overview
        </button>
        <button className="nav-item" onClick={() => onNav("transactions")}>
          <Receipt size={18} /> Transactions <span className="nav-badge">{count}</span>
        </button>
        <button className="nav-item" onClick={() => onNav("agent")}>
          <Bot size={18} /> Agent audit
        </button>
      </nav>
      <div className="side-card">
        <ShieldCheck size={20} />
        <div className="side-card-title">Demo-safe mode</div>
        <p>Sample data is fictional. Approval actions are simulated and never sent.</p>
        <div className="side-version">WORKSHOP BUILD · v1.0.0</div>
      </div>
    </aside>
  );
}

// ---------------------------------------------------------------------- app
export default function App() {
  const [transactions, setTransactions] = useState([]);
  const [source, setSource] = useState("Sample data");
  const [geminiOn, setGeminiOn] = useState(false);
  const [error, setError] = useState("");
  const [notes, setNotes] = useState([]);
  const [text, setText] = useState("");
  const [file, setFile] = useState(null);
  const [dragging, setDragging] = useState(false);
  const [goal, setGoal] = useState(DEFAULT_GOAL);
  const [audit, setAudit] = useState(null);
  const [busy, setBusy] = useState({ sample: false, extract: false, audit: false, approval: false });
  const fileInput = useRef(null);

  const setBusyFlag = (k, v) => setBusy((b) => ({ ...b, [k]: v }));
  const dash = useMemo(() => computeDashboard(transactions), [transactions]);

  const loadSample = useCallback(async () => {
    setError(""); setAudit(null); setNotes([]);
    setBusyFlag("sample", true);
    try {
      const data = await request("/api/sample");
      setTransactions(data.transactions);
      setSource("Sample data");
    } catch {
      setError("Could not load sample data. Is the backend running?");
    } finally {
      setBusyFlag("sample", false);
    }
  }, []);

  useEffect(() => {
    loadSample();
    request("/api/health")
      .then((h) => setGeminiOn(Boolean(h.gemini_configured)))
      .catch(() => setGeminiOn(false)); // falls back to "Demo mode available"
  }, [loadSample]);

  const pickFile = (f) => {
    if (!f) return;
    if (f.size > MAX_FILE_BYTES) {
      setError("Please use a file smaller than 12 MB for this classroom demo.");
      return;
    }
    setError("");
    setFile(f);
  };

  const extract = async () => {
    setError(""); setAudit(null); setNotes([]);
    setBusyFlag("extract", true);
    try {
      const form = new FormData();
      if (text.trim()) form.append("text", text);
      if (file) form.append("file", file);
      const data = await request("/api/extract", { method: "POST", body: form });
      const extra = (data.validation_errors || []).map((e) => `Row ${e.row} was dropped: ${e.error}`);
      setNotes([...(data.notes || []), ...extra]);
      if (!data.count) {
        setError("No valid transactions were extracted. Check the input and try again.");
      } else {
        setTransactions(data.transactions);
        setSource("Your input");
      }
    } catch (e) {
      setError(e.message); // existing transactions stay untouched
    } finally {
      setBusyFlag("extract", false);
    }
  };

  const runAudit = async () => {
    setError(""); setAudit(null);
    setBusyFlag("audit", true);
    try {
      const data = await request("/api/audits", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ transactions, goal: goal.trim() || DEFAULT_GOAL }),
      });
      setAudit(data);
    } catch (e) {
      setError(e.message);
    } finally {
      setBusyFlag("audit", false);
    }
  };

  const decide = async (decision) => {
    setError("");
    setBusyFlag("approval", true);
    try {
      const data = await request(`/api/audits/${audit.session_id}/approval`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ decision }),
      });
      setAudit(data);
    } catch (e) {
      setError(e.message);
    } finally {
      setBusyFlag("approval", false);
    }
  };

  const scrollTo = (id) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  const canExtract = (text.trim() || file) && !busy.extract;
  const maxCat = dash.categories[0]?.amount || 1;
  const action = audit?.pending_action;
  const decided = action && typeof action.approved === "boolean";

  return (
    <div className="app">
      <Sidebar count={dash.count} onNav={scrollTo} />

      <main className="main" id="overview">
        {/* Top bar */}
        <header className="topbar">
          <div>
            <div className="eyebrow">PERSONAL FINANCE / OVERVIEW</div>
            <h1>Finance overview</h1>
            <p className="subtitle">Understand your spending. Let your agent investigate the details.</p>
          </div>
          <div className="topbar-right">
            <span className="status">
              <span className={`dot ${geminiOn ? "on" : ""}`} />
              {geminiOn ? "Gemini connected" : "Demo mode available"}
            </span>
            <button className="icon-btn" onClick={loadSample} disabled={busy.sample}
                    title="Reload sample data" aria-label="Reload sample data">
              <RefreshCw size={18} className={busy.sample ? "spin" : ""} />
            </button>
            <span className="user-avatar">N</span>
          </div>
        </header>

        {error && (
          <div className="banner" role="alert">
            <AlertCircle size={18} />
            <span>{error}</span>
            <button onClick={() => setError("")} aria-label="Dismiss error"><X size={16} /></button>
          </div>
        )}

        {/* Metrics */}
        <section className="metrics">
          <MetricCard icon={Receipt} tone="blue" label="Total transactions" value={dash.count}
                      sub={`${dash.merchants} unique merchants`} />
          <MetricCard icon={Wallet} tone="violet" label="Total outflow" value={money(dash.totalOutflow)}
                      sub="Across loaded transactions" />
          <MetricCard icon={Repeat} tone="amber" label="Subscription charges" value={money(dash.subscriptions)}
                      sub="All visible periods combined" />
          <MetricCard icon={TrendingUp} tone="green" label="Potential price hikes"
                      value={audit ? audit.findings.length : "—"}
                      sub={audit ? "Found by the agent" : "Run an agent audit"} />
        </section>

        {/* Chart + categories */}
        <section className="two-col">
          <div className="card panel">
            <div className="panel-head">
              <div>
                <h2>Spending activity</h2>
                <p className="muted">Monthly transaction outflow</p>
              </div>
              <span className="pill">{source}</span>
            </div>
            {dash.monthly.length ? (
              <div className="chart-box">
                <ResponsiveContainer width="100%" height={260}>
                  <AreaChart data={dash.monthly} margin={{ top: 10, right: 12, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="fill" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#6d78e8" stopOpacity={0.35} />
                        <stop offset="100%" stopColor="#6d78e8" stopOpacity={0.02} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="4 4" vertical={false} stroke="#e4e7f0" />
                    <XAxis dataKey="label" tickLine={false} axisLine={false} tick={{ fill: "#8a90a6", fontSize: 12 }} />
                    <YAxis tickLine={false} axisLine={false} tick={{ fill: "#8a90a6", fontSize: 12 }}
                           tickFormatter={(v) => `$${v}`} width={52} />
                    <Tooltip formatter={(v) => [money(v), "Outflow"]} />
                    <Area type="monotone" dataKey="amount" stroke="#6d78e8" strokeWidth={2.5} fill="url(#fill)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="empty">Add dated transactions to see spending activity.</div>
            )}
          </div>

          <div className="card panel">
            <div className="panel-head">
              <div>
                <h2>Spending by category</h2>
                <p className="muted">Positive charges only</p>
              </div>
            </div>
            {dash.categories.length ? (
              <ul className="cats">
                {dash.categories.map((c, i) => (
                  <li key={c.name}>
                    <span className="cat-icon" style={{ background: `${CAT_COLORS[i]}22`, color: CAT_COLORS[i] }}>
                      {c.name.charAt(0)}
                    </span>
                    <div className="cat-body">
                      <div className="cat-row"><span>{c.name}</span><strong>{money(c.amount)}</strong></div>
                      <div className="bar"><div style={{
                        width: `${Math.max(3, (c.amount / maxCat) * 100)}%`, background: CAT_COLORS[i],
                      }} /></div>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <div className="empty">Category totals appear after transactions are loaded.</div>
            )}
          </div>
        </section>

        {/* Import */}
        <section className="card panel import">
          <div className="panel-head">
            <div>
              <div className="kicker">GENAI EXTRACTION</div>
              <h2>Bring in financial data</h2>
            </div>
            <span className="tag">01 Extract &amp; validate</span>
          </div>

          <div className="import-grid">
            <div
              className={`dropzone ${dragging ? "drag" : ""}`}
              onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
              onDragLeave={() => setDragging(false)}
              onDrop={(e) => { e.preventDefault(); setDragging(false); pickFile(e.dataTransfer.files?.[0]); }}
            >
              <input ref={fileInput} type="file" accept="image/*,.pdf,.csv,.txt" hidden
                     onChange={(e) => { pickFile(e.target.files?.[0]); e.target.value = ""; }} />
              {file ? (
                <>
                  <FileText size={28} />
                  <div className="dz-title">{file.name}</div>
                  <div className="muted">{(file.size / 1024).toFixed(1)} KB</div>
                  <button className="btn secondary small" onClick={() => setFile(null)}>Remove</button>
                </>
              ) : (
                <>
                  <UploadCloud size={28} />
                  <div className="dz-title">Choose a receipt or statement</div>
                  <div className="muted">PNG, JPG, PDF, CSV or TXT · max 12 MB</div>
                  <button className="btn secondary small" onClick={() => fileInput.current?.click()}>Browse files</button>
                </>
              )}
            </div>

            <div className="or">OR</div>

            <div className="paste">
              <label htmlFor="raw-text">Paste raw transaction text</label>
              <textarea id="raw-text" rows={4} value={text} onChange={(e) => setText(e.target.value)}
                        placeholder={EXAMPLE_TEXT} />
              <div className="helper">
                <span>Raw text is sent to Gemini when configured.</span>
                <button className="link" onClick={() => setText(EXAMPLE_TEXT)}>Use example</button>
              </div>
            </div>
          </div>

          <div className="import-foot">
            <p className="muted">
              Structured output + Pydantic validation. Unclear fields should stay null, not guessed.
            </p>
            <div className="btn-row">
              <button className="btn secondary" onClick={loadSample} disabled={busy.sample}>
                {busy.sample && <Spinner />} Load sample data
              </button>
              <button className="btn primary" onClick={extract} disabled={!canExtract}>
                {busy.extract ? <Spinner /> : <Sparkles size={16} />} Extract transactions
              </button>
            </div>
          </div>

          {notes.length > 0 && (
            <div className="notes">
              <strong>Extraction notes</strong>
              <ul>{notes.map((n, i) => <li key={i}>{n}</li>)}</ul>
            </div>
          )}
        </section>

        {/* Transactions */}
        <section className="card panel" id="transactions">
          <div className="panel-head">
            <div>
              <h2>Transactions</h2>
              <p className="muted">Validated, typed records feeding your dashboard</p>
            </div>
            <span className="pill">{dash.count} records</span>
          </div>
          {dash.rows.length ? (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr><th>MERCHANT</th><th>DATE</th><th>CATEGORY</th><th>RAW SOURCE</th><th className="right">AMOUNT</th></tr>
                </thead>
                <tbody>
                  {dash.rows.map((t, i) => (
                    <tr key={i}>
                      <td><div className="merchant"><Avatar name={t.merchant} /><strong>{t.merchant}</strong></div></td>
                      <td>{fmtDay(t.date)}</td>
                      <td><span className="chip">{t.category}</span></td>
                      <td className="mono">{t.raw_line || "—"}</td>
                      <td className={`right amount ${t.amount < 0 ? "refund" : ""}`}>
                        {t.amount < 0 ? <ArrowDownLeft size={14} /> : <ArrowUpRight size={14} />}
                        {money(Math.abs(t.amount))}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="empty">No transactions yet. Load sample data or extract a statement above.</div>
          )}
        </section>

        {/* Agent */}
        <section id="agent" className="agent">
          <div className="kicker">AUTONOMOUS AGENT</div>
          <h2 className="agent-title">Run a finance audit</h2>
          <p className="muted">The agent investigates with Python tools, then asks before any consequential action.</p>

          <div className="two-col agent-grid">
            <div className="card panel">
              <label htmlFor="goal" className="field-label">Your audit goal</label>
              <textarea id="goal" rows={4} value={goal} onChange={(e) => setGoal(e.target.value)} />
              <p className="safety-note">
                <ShieldCheck size={16} />
                Read-only analysis runs automatically. Cancellation / dispute actions are drafts and require
                your approval. Nothing is sent.
              </p>
              <button className="btn primary full" onClick={runAudit}
                      disabled={busy.audit || transactions.length === 0}>
                {busy.audit ? <Spinner /> : <Bot size={16} />} Run agent audit
              </button>
            </div>

            <div className="card panel">
              <div className="panel-head">
                <div>
                  <h2>Agent trace</h2>
                  <p className="muted">Tools, observations and decisions</p>
                </div>
                {audit && <span className={`status-pill s-${audit.status}`}>{audit.status.replace("_", " ")}</span>}
              </div>
              {audit ? (
                <>
                  {audit.summary && <div className="summary">{audit.summary}</div>}
                  <ol className="timeline">
                    {audit.audit_log.map((e, i) => (
                      <li key={i} className={`t-${traceTone(e.type)}`}>
                        <span className="t-dot" />
                        <div>
                          <div className="t-msg">{e.message}</div>
                          <div className="t-meta">{e.type} · {fmtTime(e.time)}</div>
                          {e.type === "plan" && e.details?.tool && (
                            <code className="t-code">{formatCall(e.details.tool, e.details.arguments)}</code>
                          )}
                        </div>
                      </li>
                    ))}
                  </ol>
                </>
              ) : (
                <div className="empty trace-empty">
                  <Bot size={30} />
                  <strong>Your audit trace will appear here</strong>
                  <p>Run an audit to watch the agent plan, call tools and stop for your approval.</p>
                  <div className="mini-steps"><span>Inspect</span>→<span>Calculate</span>→<span>Ask first</span></div>
                </div>
              )}
            </div>
          </div>

          {audit?.findings?.length > 0 && (
            <div className="findings">
              {audit.findings.map((f, i) => (
                <div key={i} className="card finding">
                  <div className="finding-top">
                    <span className="badge amber"><TrendingUp size={14} /> Price increase detected</span>
                    <strong className="finding-pct">+{Number(f.change_pct).toFixed(0)}%</strong>
                  </div>
                  <h3>{f.merchant}</h3>
                  <div className="finding-price">{money(f.old_amount)} → <strong>{money(f.new_amount)}</strong>/month</div>
                  <div className="finding-foot">
                    <span>Detected {fmtDay(f.date)}</span>
                    <span>+{money(f.monthly_increase)} / month</span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {action && (
            <div className="card approval">
              <div className="approval-head">
                <div>
                  <div className="kicker">HUMAN-IN-THE-LOOP</div>
                  <h2>
                    {!decided ? "Action needs your approval"
                      : action.approved ? "Action approved (simulation)" : "Proposed action reviewed"}
                  </h2>
                  <p className="muted">{action.merchant} · Subscription change review</p>
                </div>
                <span className={`status-pill ${decided ? "s-done" : "s-awaiting_approval"}`}>
                  {decided ? "Decision recorded" : "Awaiting decision"}
                </span>
              </div>
              <div className="facts">
                <div><span>Price increase</span><strong>+{Number(action.change_pct).toFixed(1)}%</strong></div>
                <div><span>Annualized cost now</span><strong>{money(action.annual_cost)}</strong></div>
                <div><span>Monthly difference</span><strong>+{money(action.monthly_increase)}</strong></div>
              </div>
              <div className="draft">
                <div className="draft-head">
                  <span className="kicker">CANCELLATION / DISPUTE DRAFT</span>
                  <span className="badge red">NOT SENT</span>
                </div>
                <pre>{action.draft}</pre>
              </div>
              <div className="approval-foot">
                <p className="muted">
                  {!decided
                    ? "Approving only records a local simulation. No email or message will be sent."
                    : action.approved
                      ? "You approved this simulation. Nothing was sent."
                      : "You rejected this proposal. Nothing was sent."}
                </p>
                {!decided && (
                  <div className="btn-row">
                    <button className="btn secondary" disabled={busy.approval} onClick={() => decide("reject")}>
                      <X size={16} /> Reject
                    </button>
                    <button className="btn primary" disabled={busy.approval} onClick={() => decide("approve")}>
                      {busy.approval ? <Spinner /> : <Check size={16} />} Approve simulation
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        </section>

        <footer className="footer">
          <span>FINWISE · FINANCE INTELLIGENCE AGENT</span>
          <span>Built for learning · Not financial advice</span>
        </footer>
      </main>
    </div>
  );
}

function traceTone(type) {
  if (type === "tool") return "green";
  if (type === "error") return "red";
  if (type === "approval_required" || type === "approved_simulation" || type === "rejected") return "amber";
  return "blue"; // started, plan, completed
}

function formatCall(tool, args) {
  const has = args && Object.keys(args).length > 0;
  return `${tool}(${has ? JSON.stringify(args) : ""})`;
}
